<!--

abstract class MiembroColegio {
    protected $nombre;
    protected $primer_apellido;
    protected $segundo_apellido;
    protected $edad;

    // Constructor vacío ya que no queremos instanciar esta clase.
    public function __construct() {

    }

    // GETTERS
    

    // SETTERS


    // Cuando el objeto realiza su función se destruye para liberar memoria.
    public function __destruct() {

    }
} 

-->